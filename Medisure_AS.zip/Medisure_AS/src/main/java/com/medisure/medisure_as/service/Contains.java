package com.medisure.medisure_as.service;

public class Contains {
    public static final String ROLE_ADMIN = "ROLE_ADMIN";
    public static final String ROLE_USER = "ROLE_USER";
    public static final String ROLE_DOCTOR = "ROLE_DOCTOR";
}
