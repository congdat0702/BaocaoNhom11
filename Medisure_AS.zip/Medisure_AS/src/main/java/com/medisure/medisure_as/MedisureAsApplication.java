package com.medisure.medisure_as;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedisureAsApplication {

    public static void main(String[] args) {
        SpringApplication.run(MedisureAsApplication.class, args);
        System.out.println("Nhóm 11 xin chào. bắt đầu nào");
    }

}
